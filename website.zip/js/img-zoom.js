mediumZoom('.zoom', {
	margin: 10,
	background: '#1B1535',
	scrollOffset: 150
})